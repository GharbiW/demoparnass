import {
  Controller,
  Get,
  Post,
  Logger,
  Query,
} from '@nestjs/common';
import { SyncService } from '../services/sync.service';
import { SyncResultDto, SyncStatusDto, SyncHistoryEntryDto } from '../dto/sync.dto';

@Controller('backoffice/sync')
export class SyncController {
  private readonly logger = new Logger(SyncController.name);

  constructor(private readonly syncService: SyncService) {}

  /**
   * POST /backoffice/sync/drivers
   * Synchronize drivers from Factorial API
   */
  @Post('drivers')
  async syncDrivers(): Promise<SyncResultDto> {
    this.logger.log('Démarrage synchronisation manuelle des conducteurs');
    return this.syncService.syncDrivers('manual');
  }

  /**
   * POST /backoffice/sync/vehicles
   * Synchronize vehicles from MyRentCar API
   */
  @Post('vehicles')
  async syncVehicles(): Promise<SyncResultDto> {
    this.logger.log('Démarrage synchronisation manuelle des véhicules');
    return this.syncService.syncVehicles('manual');
  }

  /**
   * POST /backoffice/sync/all
   * Synchronize both drivers and vehicles
   */
  @Post('all')
  async syncAll(): Promise<{
    drivers: SyncResultDto;
    vehicles: SyncResultDto;
  }> {
    this.logger.log('Démarrage synchronisation manuelle complète');
    return this.syncService.syncAll('manual');
  }

  /**
   * GET /backoffice/sync/status
   * Get current sync status
   */
  @Get('status')
  async getStatus(): Promise<SyncStatusDto> {
    return this.syncService.getStatus();
  }

  /**
   * GET /backoffice/sync/history
   * Get sync history
   */
  @Get('history')
  async getHistory(
    @Query('limit') limit?: number,
  ): Promise<SyncHistoryEntryDto[]> {
    return this.syncService.getHistory(limit || 10);
  }
}
