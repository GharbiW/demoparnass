import {
  Controller,
  Get,
  Patch,
  Param,
  Body,
  Query,
  UseGuards,
  Logger,
} from '@nestjs/common';
import { VehiclesCacheService } from '../services/vehicles-cache.service';
import {
  VehicleCacheResponseDto,
  VehicleStatsDto,
  UpdateVehicleManualFieldsDto,
  ListVehiclesQueryDto,
} from '../dto/vehicle.dto';

@Controller('backoffice/vehicles')
export class VehiclesController {
  private readonly logger = new Logger(VehiclesController.name);

  constructor(private readonly vehiclesCacheService: VehiclesCacheService) {}

  /**
   * GET /backoffice/vehicles
   * List all cached vehicles with optional filtering
   */
  @Get()
  async findAll(
    @Query() query: ListVehiclesQueryDto,
  ): Promise<VehicleCacheResponseDto[]> {
    this.logger.debug(`Récupération véhicules avec filtres: ${JSON.stringify(query)}`);
    return this.vehiclesCacheService.findAll(query);
  }

  /**
   * GET /backoffice/vehicles/stats/summary
   * Get vehicle statistics
   */
  @Get('stats/summary')
  async getStats(): Promise<VehicleStatsDto> {
    return this.vehiclesCacheService.getStats();
  }

  /**
   * GET /backoffice/vehicles/:id
   * Get a single vehicle by ID
   */
  @Get(':id')
  async findOne(@Param('id') id: string): Promise<VehicleCacheResponseDto> {
    return this.vehiclesCacheService.findOne(id);
  }

  /**
   * PATCH /backoffice/vehicles/:id
   * Update manual fields for a vehicle
   */
  @Patch(':id')
  async updateManualFields(
    @Param('id') id: string,
    @Body() dto: UpdateVehicleManualFieldsDto,
  ): Promise<VehicleCacheResponseDto> {
    this.logger.debug(`Mise à jour véhicule ${id}: ${JSON.stringify(dto)}`);
    return this.vehiclesCacheService.updateManualFields(id, dto);
  }
}
