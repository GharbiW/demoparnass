import {
  Injectable,
  NotFoundException,
  BadRequestException,
  Logger,
} from '@nestjs/common';
import { SupabaseService } from '../../../config/supabase.service';
import {
  DriverCacheResponseDto,
  DriverStatsDto,
  UpdateDriverManualFieldsDto,
  ListDriversQueryDto,
  DRIVER_API_FIELDS,
} from '../dto/driver.dto';

@Injectable()
export class DriversCacheService {
  private readonly logger = new Logger(DriversCacheService.name);

  constructor(private readonly supabaseService: SupabaseService) {}

  private get supabase() {
    return this.supabaseService.getClient();
  }

  /**
   * Transform database row to response DTO
   */
  private transformDriver(row: any): DriverCacheResponseDto {
    return {
      id: row.id,
      factorialId: row.factorial_id,
      firstName: row.first_name,
      lastName: row.last_name,
      email: row.email,
      phone: row.phone,
      address: row.address,
      postalCode: row.postal_code,
      city: row.city,
      country: row.country,
      birthday: row.birthday,
      teamId: row.team_id,
      teamName: row.team_name,
      shift: row.shift,
      availableWeekends: row.available_weekends,
      // Manual fields
      matricule: row.matricule,
      permits: row.permits || [],
      certifications: row.certifications || [],
      visiteMedicale: row.visite_medicale,
      agence: row.agence,
      zone: row.zone,
      amplitude: row.amplitude,
      decoucher: row.decoucher,
      status: row.status || 'disponible',
      indisponibiliteRaison: row.indisponibilite_raison,
      // Metadata
      _apiFields: DRIVER_API_FIELDS,
      syncedAt: row.synced_at,
      createdAt: row.created_at,
      updatedAt: row.updated_at,
    };
  }

  /**
   * Find all drivers with optional filtering
   */
  async findAll(query: ListDriversQueryDto): Promise<DriverCacheResponseDto[]> {
    let dbQuery = this.supabase.from('driver_cache').select('*');

    // Apply filters
    if (query.status) {
      dbQuery = dbQuery.eq('status', query.status);
    }

    if (query.teamName) {
      dbQuery = dbQuery.eq('team_name', query.teamName);
    }

    if (query.agence) {
      dbQuery = dbQuery.eq('agence', query.agence);
    }

    if (query.search) {
      const searchLower = query.search.toLowerCase();
      dbQuery = dbQuery.or(
        `first_name.ilike.%${searchLower}%,last_name.ilike.%${searchLower}%,matricule.ilike.%${searchLower}%`,
      );
    }

    // Pagination - default to 10000 to avoid Supabase's 1000 row limit
    const limit = query.limit || 10000;
    dbQuery = dbQuery.limit(limit);

    if (query.offset) {
      dbQuery = dbQuery.range(query.offset, query.offset + limit - 1);
    }

    // Order by name
    dbQuery = dbQuery.order('last_name').order('first_name');

    const { data, error } = await dbQuery;

    if (error) {
      this.logger.error('Erreur lors de la récupération des conducteurs', error);
      throw new BadRequestException(error.message);
    }

    return (data || []).map((row) => this.transformDriver(row));
  }

  /**
   * Find a single driver by ID
   */
  async findOne(id: string): Promise<DriverCacheResponseDto> {
    const { data, error } = await this.supabase
      .from('driver_cache')
      .select('*')
      .eq('id', id)
      .single();

    if (error || !data) {
      throw new NotFoundException(`Conducteur non trouvé: ${id}`);
    }

    return this.transformDriver(data);
  }

  /**
   * Find a driver by Factorial ID
   */
  async findByFactorialId(factorialId: number): Promise<DriverCacheResponseDto | null> {
    const { data, error } = await this.supabase
      .from('driver_cache')
      .select('*')
      .eq('factorial_id', factorialId)
      .single();

    if (error || !data) {
      return null;
    }

    return this.transformDriver(data);
  }

  /**
   * Get driver statistics
   */
  async getStats(): Promise<DriverStatsDto> {
    // Use explicit count to get accurate total
    const { count: totalCount, error: countError } = await this.supabase
      .from('driver_cache')
      .select('*', { count: 'exact', head: true });

    if (countError) {
      this.logger.error('Erreur lors du comptage des conducteurs', countError);
      throw new BadRequestException(countError.message);
    }

    // Get status breakdown with high limit
    const { data, error } = await this.supabase
      .from('driver_cache')
      .select('status, synced_at')
      .limit(50000);

    if (error) {
      this.logger.error('Erreur lors de la récupération des statistiques', error);
      throw new BadRequestException(error.message);
    }

    const stats: DriverStatsDto = {
      total: totalCount || 0,
      disponibles: 0,
      occupes: 0,
      indisponibles: 0,
      lastSyncAt: undefined,
    };

    let latestSyncDate: Date | null = null;

    (data || []).forEach((row: any) => {
      switch (row.status) {
        case 'disponible':
          stats.disponibles++;
          break;
        case 'occupe':
          stats.occupes++;
          break;
        case 'indisponible':
          stats.indisponibles++;
          break;
      }

      if (row.synced_at) {
        const syncDate = new Date(row.synced_at);
        if (!latestSyncDate || syncDate > latestSyncDate) {
          latestSyncDate = syncDate;
        }
      }
    });

    if (latestSyncDate !== null) {
      stats.lastSyncAt = (latestSyncDate as Date).toISOString();
    }

    return stats;
  }

  /**
   * Update manual fields (not synced from API)
   */
  async updateManualFields(
    id: string,
    dto: UpdateDriverManualFieldsDto,
  ): Promise<DriverCacheResponseDto> {
    // First check if driver exists
    await this.findOne(id);

    const updateData: any = {
      updated_at: new Date().toISOString(),
    };

    if (dto.matricule !== undefined) updateData.matricule = dto.matricule;
    if (dto.permits !== undefined) updateData.permits = dto.permits;
    if (dto.certifications !== undefined) updateData.certifications = dto.certifications;
    if (dto.visiteMedicale !== undefined) updateData.visite_medicale = dto.visiteMedicale;
    if (dto.agence !== undefined) updateData.agence = dto.agence;
    if (dto.zone !== undefined) updateData.zone = dto.zone;
    if (dto.amplitude !== undefined) updateData.amplitude = dto.amplitude;
    if (dto.decoucher !== undefined) updateData.decoucher = dto.decoucher;
    if (dto.status !== undefined) updateData.status = dto.status;
    if (dto.indisponibiliteRaison !== undefined) {
      updateData.indisponibilite_raison = dto.indisponibiliteRaison;
    }

    const { data, error } = await this.supabase
      .from('driver_cache')
      .update(updateData)
      .eq('id', id)
      .select()
      .single();

    if (error) {
      this.logger.error('Erreur lors de la mise à jour du conducteur', error);
      throw new BadRequestException(error.message);
    }

    return this.transformDriver(data);
  }

  /**
   * Upsert a driver from Factorial API data
   * Preserves manual fields when updating
   */
  async upsertFromApi(apiData: {
    factorial_id: number;
    first_name: string;
    last_name: string;
    email?: string;
    phone?: string;
    address?: string;
    postal_code?: string;
    city?: string;
    country?: string;
    birthday?: string;
    team_id?: number;
    team_name?: string;
    shift?: string;
    available_weekends?: string;
  }): Promise<{ created: boolean; updated: boolean }> {
    // Check if driver already exists
    const existing = await this.findByFactorialId(apiData.factorial_id);

    const now = new Date().toISOString();

    if (existing) {
      // Update only API fields, preserve manual fields
      const { error } = await this.supabase
        .from('driver_cache')
        .update({
          first_name: apiData.first_name,
          last_name: apiData.last_name,
          email: apiData.email,
          phone: apiData.phone,
          address: apiData.address,
          postal_code: apiData.postal_code,
          city: apiData.city,
          country: apiData.country,
          birthday: apiData.birthday,
          team_id: apiData.team_id,
          team_name: apiData.team_name,
          shift: apiData.shift,
          available_weekends: apiData.available_weekends,
          synced_at: now,
          updated_at: now,
        })
        .eq('factorial_id', apiData.factorial_id);

      if (error) {
        this.logger.error(`Erreur mise à jour conducteur ${apiData.factorial_id}`, error);
        throw new BadRequestException(error.message);
      }

      return { created: false, updated: true };
    } else {
      // Create new driver
      const { error } = await this.supabase.from('driver_cache').insert({
        factorial_id: apiData.factorial_id,
        first_name: apiData.first_name,
        last_name: apiData.last_name,
        email: apiData.email,
        phone: apiData.phone,
        address: apiData.address,
        postal_code: apiData.postal_code,
        city: apiData.city,
        country: apiData.country,
        birthday: apiData.birthday,
        team_id: apiData.team_id,
        team_name: apiData.team_name,
        shift: apiData.shift,
        available_weekends: apiData.available_weekends,
        status: 'disponible',
        permits: [],
        certifications: [],
        synced_at: now,
        created_at: now,
        updated_at: now,
      });

      if (error) {
        this.logger.error(`Erreur création conducteur ${apiData.factorial_id}`, error);
        throw new BadRequestException(error.message);
      }

      return { created: true, updated: false };
    }
  }

  /**
   * Get count of drivers in cache
   */
  async getCount(): Promise<number> {
    const { count, error } = await this.supabase
      .from('driver_cache')
      .select('*', { count: 'exact', head: true });

    if (error) {
      this.logger.error('Erreur lors du comptage des conducteurs', error);
      return 0;
    }

    return count || 0;
  }
}
