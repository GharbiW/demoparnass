import {
  Injectable,
  NotFoundException,
  BadRequestException,
  Logger,
} from '@nestjs/common';
import { SupabaseService } from '../../../config/supabase.service';
import {
  VehicleCacheResponseDto,
  VehicleStatsDto,
  UpdateVehicleManualFieldsDto,
  ListVehiclesQueryDto,
  VEHICLE_API_FIELDS,
} from '../dto/vehicle.dto';

@Injectable()
export class VehiclesCacheService {
  private readonly logger = new Logger(VehiclesCacheService.name);

  constructor(private readonly supabaseService: SupabaseService) {}

  private get supabase() {
    return this.supabaseService.getClient();
  }

  /**
   * Transform database row to response DTO
   */
  private transformVehicle(row: any, titulaire?: any): VehicleCacheResponseDto {
    const response: VehicleCacheResponseDto = {
      id: row.id,
      myrentcarId: row.myrentcar_id,
      numero: row.numero,
      immatriculation: row.immatriculation,
      type: row.type,
      typeCode: row.type_code,
      marqueModele: row.marque_modele,
      energie: row.energie,
      energieId: row.energie_id,
      kilometrage: row.kilometrage,
      dateDernierKm: row.date_dernier_km,
      dateMiseCirculation: row.date_mise_circulation,
      capaciteReservoir: row.capacite_reservoir,
      poidsVide: row.poids_vide,
      poidsCharge: row.poids_charge,
      primeVolume: row.prime_volume,
      agenceProprietaire: row.agence_proprietaire,
      categoryCode: row.category_code,
      numeroSerie: row.numero_serie,
      // Manual fields
      status: row.status || 'disponible',
      semiCompatibles: row.semi_compatibles || [],
      equipements: row.equipements || [],
      localisation: row.localisation,
      lastPositionUpdate: row.last_position_update,
      prochainCt: row.prochain_ct,
      prochainEntretien: row.prochain_entretien,
      titulaireId: row.titulaire_id,
      // Metadata
      _apiFields: VEHICLE_API_FIELDS,
      syncedAt: row.synced_at,
      createdAt: row.created_at,
      updatedAt: row.updated_at,
    };

    // Add titulaire details if available
    if (titulaire) {
      response.titulaire = {
        id: titulaire.id,
        nom: `${titulaire.first_name} ${titulaire.last_name}`,
      };
    }

    // Add maintenance details if in maintenance
    if (row.status === 'maintenance' && row.maintenance_type) {
      response.maintenanceDetails = {
        type: row.maintenance_type,
        dateEntree: row.maintenance_date_entree,
        etr: row.maintenance_etr,
      };
    }

    return response;
  }

  /**
   * Find all vehicles with optional filtering
   */
  async findAll(query: ListVehiclesQueryDto): Promise<VehicleCacheResponseDto[]> {
    let dbQuery = this.supabase.from('vehicle_cache').select('*');

    // Apply filters
    if (query.status) {
      dbQuery = dbQuery.eq('status', query.status);
    }

    if (query.type) {
      dbQuery = dbQuery.eq('type', query.type);
    }

    if (query.energie) {
      dbQuery = dbQuery.eq('energie', query.energie);
    }

    if (query.search) {
      const searchLower = query.search.toLowerCase();
      dbQuery = dbQuery.or(
        `immatriculation.ilike.%${searchLower}%,marque_modele.ilike.%${searchLower}%,numero.ilike.%${searchLower}%`,
      );
    }

    // Pagination - default to 10000 to avoid Supabase's 1000 row limit
    const limit = query.limit || 10000;
    dbQuery = dbQuery.limit(limit);

    if (query.offset) {
      dbQuery = dbQuery.range(query.offset, query.offset + limit - 1);
    }

    // Order by immatriculation
    dbQuery = dbQuery.order('immatriculation');

    const { data, error } = await dbQuery;

    if (error) {
      this.logger.error('Erreur lors de la récupération des véhicules', error);
      throw new BadRequestException(error.message);
    }

    // Get titulaires for vehicles that have one
    const titulaireIds = (data || [])
      .filter((v: any) => v.titulaire_id)
      .map((v: any) => v.titulaire_id);

    let titulairesMap = new Map();
    if (titulaireIds.length > 0) {
      const { data: titulaires } = await this.supabase
        .from('driver_cache')
        .select('id, first_name, last_name')
        .in('id', titulaireIds);

      if (titulaires) {
        titulaires.forEach((t: any) => {
          titulairesMap.set(t.id, t);
        });
      }
    }

    return (data || []).map((row: any) => 
      this.transformVehicle(row, titulairesMap.get(row.titulaire_id))
    );
  }

  /**
   * Find a single vehicle by ID
   */
  async findOne(id: string): Promise<VehicleCacheResponseDto> {
    const { data, error } = await this.supabase
      .from('vehicle_cache')
      .select('*')
      .eq('id', id)
      .single();

    if (error || !data) {
      throw new NotFoundException(`Véhicule non trouvé: ${id}`);
    }

    // Get titulaire if exists
    let titulaire: { id: string; first_name: string; last_name: string } | null = null;
    if (data.titulaire_id) {
      const { data: titulaireData } = await this.supabase
        .from('driver_cache')
        .select('id, first_name, last_name')
        .eq('id', data.titulaire_id)
        .single();
      titulaire = titulaireData;
    }

    return this.transformVehicle(data, titulaire);
  }

  /**
   * Find a vehicle by MyRentCar ID
   */
  async findByMyRentCarId(myrentcarId: number): Promise<VehicleCacheResponseDto | null> {
    const { data, error } = await this.supabase
      .from('vehicle_cache')
      .select('*')
      .eq('myrentcar_id', myrentcarId)
      .single();

    if (error || !data) {
      return null;
    }

    return this.transformVehicle(data);
  }

  /**
   * Get vehicle statistics
   */
  async getStats(): Promise<VehicleStatsDto> {
    // Use explicit count to get accurate total
    const { count: totalCount, error: countError } = await this.supabase
      .from('vehicle_cache')
      .select('*', { count: 'exact', head: true });

    if (countError) {
      this.logger.error('Erreur lors du comptage des véhicules', countError);
      throw new BadRequestException(countError.message);
    }

    // Get status breakdown with high limit
    const { data, error } = await this.supabase
      .from('vehicle_cache')
      .select('status, synced_at')
      .limit(50000);

    if (error) {
      this.logger.error('Erreur lors de la récupération des statistiques', error);
      throw new BadRequestException(error.message);
    }

    const stats: VehicleStatsDto = {
      total: totalCount || 0,
      disponibles: 0,
      enTournee: 0,
      maintenance: 0,
      indisponibles: 0,
      lastSyncAt: undefined,
    };

    let latestSyncDate: Date | null = null;

    (data || []).forEach((row: any) => {
      switch (row.status) {
        case 'disponible':
          stats.disponibles++;
          break;
        case 'en_tournee':
          stats.enTournee++;
          break;
        case 'maintenance':
          stats.maintenance++;
          break;
        case 'indisponible':
          stats.indisponibles++;
          break;
      }

      if (row.synced_at) {
        const syncDate = new Date(row.synced_at);
        if (!latestSyncDate || syncDate > latestSyncDate) {
          latestSyncDate = syncDate;
        }
      }
    });

    if (latestSyncDate !== null) {
      stats.lastSyncAt = (latestSyncDate as Date).toISOString();
    }

    return stats;
  }

  /**
   * Update manual fields (not synced from API)
   */
  async updateManualFields(
    id: string,
    dto: UpdateVehicleManualFieldsDto,
  ): Promise<VehicleCacheResponseDto> {
    // First check if vehicle exists
    await this.findOne(id);

    const updateData: any = {
      updated_at: new Date().toISOString(),
    };

    if (dto.status !== undefined) updateData.status = dto.status;
    if (dto.semiCompatibles !== undefined) updateData.semi_compatibles = dto.semiCompatibles;
    if (dto.equipements !== undefined) updateData.equipements = dto.equipements;
    if (dto.localisation !== undefined) updateData.localisation = dto.localisation;
    if (dto.lastPositionUpdate !== undefined) updateData.last_position_update = dto.lastPositionUpdate;
    if (dto.prochainCt !== undefined) updateData.prochain_ct = dto.prochainCt;
    if (dto.prochainEntretien !== undefined) updateData.prochain_entretien = dto.prochainEntretien;
    if (dto.titulaireId !== undefined) updateData.titulaire_id = dto.titulaireId;
    if (dto.maintenanceType !== undefined) updateData.maintenance_type = dto.maintenanceType;
    if (dto.maintenanceDateEntree !== undefined) updateData.maintenance_date_entree = dto.maintenanceDateEntree;
    if (dto.maintenanceEtr !== undefined) updateData.maintenance_etr = dto.maintenanceEtr;

    const { data, error } = await this.supabase
      .from('vehicle_cache')
      .update(updateData)
      .eq('id', id)
      .select()
      .single();

    if (error) {
      this.logger.error('Erreur lors de la mise à jour du véhicule', error);
      throw new BadRequestException(error.message);
    }

    return this.transformVehicle(data);
  }

  /**
   * Upsert a vehicle from MyRentCar API data
   * Preserves manual fields when updating
   */
  async upsertFromApi(apiData: {
    myrentcar_id: number;
    numero?: string;
    immatriculation: string;
    type?: string;
    type_code?: string;
    marque_modele?: string;
    energie?: string;
    energie_id?: number;
    kilometrage?: number;
    date_dernier_km?: string;
    date_mise_circulation?: string;
    capacite_reservoir?: number;
    poids_vide?: string;
    poids_charge?: string;
    prime_volume?: number;
    agence_proprietaire?: string;
    category_code?: string;
    numero_serie?: string;
  }): Promise<{ created: boolean; updated: boolean }> {
    // Check if vehicle already exists
    const existing = await this.findByMyRentCarId(apiData.myrentcar_id);

    const now = new Date().toISOString();

    if (existing) {
      // Update only API fields, preserve manual fields
      const { error } = await this.supabase
        .from('vehicle_cache')
        .update({
          numero: apiData.numero,
          immatriculation: apiData.immatriculation,
          type: apiData.type,
          type_code: apiData.type_code,
          marque_modele: apiData.marque_modele,
          energie: apiData.energie,
          energie_id: apiData.energie_id,
          kilometrage: apiData.kilometrage,
          date_dernier_km: apiData.date_dernier_km,
          date_mise_circulation: apiData.date_mise_circulation,
          capacite_reservoir: apiData.capacite_reservoir,
          poids_vide: apiData.poids_vide,
          poids_charge: apiData.poids_charge,
          prime_volume: apiData.prime_volume,
          agence_proprietaire: apiData.agence_proprietaire,
          category_code: apiData.category_code,
          numero_serie: apiData.numero_serie,
          synced_at: now,
          updated_at: now,
        })
        .eq('myrentcar_id', apiData.myrentcar_id);

      if (error) {
        this.logger.error(`Erreur mise à jour véhicule ${apiData.myrentcar_id}`, error);
        throw new BadRequestException(error.message);
      }

      return { created: false, updated: true };
    } else {
      // Create new vehicle
      const { error } = await this.supabase.from('vehicle_cache').insert({
        myrentcar_id: apiData.myrentcar_id,
        numero: apiData.numero,
        immatriculation: apiData.immatriculation,
        type: apiData.type,
        type_code: apiData.type_code,
        marque_modele: apiData.marque_modele,
        energie: apiData.energie,
        energie_id: apiData.energie_id,
        kilometrage: apiData.kilometrage,
        date_dernier_km: apiData.date_dernier_km,
        date_mise_circulation: apiData.date_mise_circulation,
        capacite_reservoir: apiData.capacite_reservoir,
        poids_vide: apiData.poids_vide,
        poids_charge: apiData.poids_charge,
        prime_volume: apiData.prime_volume,
        agence_proprietaire: apiData.agence_proprietaire,
        category_code: apiData.category_code,
        numero_serie: apiData.numero_serie,
        status: 'disponible',
        semi_compatibles: [],
        equipements: [],
        synced_at: now,
        created_at: now,
        updated_at: now,
      });

      if (error) {
        this.logger.error(`Erreur création véhicule ${apiData.myrentcar_id}`, error);
        throw new BadRequestException(error.message);
      }

      return { created: true, updated: false };
    }
  }

  /**
   * Get count of vehicles in cache
   */
  async getCount(): Promise<number> {
    const { count, error } = await this.supabase
      .from('vehicle_cache')
      .select('*', { count: 'exact', head: true });

    if (error) {
      this.logger.error('Erreur lors du comptage des véhicules', error);
      return 0;
    }

    return count || 0;
  }
}
