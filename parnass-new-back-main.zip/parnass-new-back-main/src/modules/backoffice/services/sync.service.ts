import { Injectable, Logger, BadRequestException } from '@nestjs/common';
import { SupabaseService } from '../../../config/supabase.service';
import { FactorialService } from './factorial.service';
import { MyRentACarService } from './my-rent-a-car.service';
import { DriversCacheService } from './drivers-cache.service';
import { VehiclesCacheService } from './vehicles-cache.service';
import { SyncResultDto, SyncStatusDto, SyncHistoryEntryDto } from '../dto/sync.dto';
import { FactorialTeam } from '../types/factorial.types';

@Injectable()
export class SyncService {
  private readonly logger = new Logger(SyncService.name);

  constructor(
    private readonly supabaseService: SupabaseService,
    private readonly factorialService: FactorialService,
    private readonly myRentACarService: MyRentACarService,
    private readonly driversCacheService: DriversCacheService,
    private readonly vehiclesCacheService: VehiclesCacheService,
  ) {}

  private get supabase() {
    return this.supabaseService.getClient();
  }

  /**
   * Create a sync status record
   */
  private async createSyncRecord(
    entityType: 'drivers' | 'vehicles' | 'all',
    triggeredBy?: string,
  ): Promise<string> {
    const { data, error } = await this.supabase
      .from('sync_status')
      .insert({
        entity_type: entityType,
        status: 'in_progress',
        started_at: new Date().toISOString(),
        triggered_by: triggeredBy,
      })
      .select('id')
      .single();

    if (error) {
      this.logger.error('Erreur création sync record', error);
      throw new BadRequestException(error.message);
    }

    return data.id;
  }

  /**
   * Update a sync status record
   */
  private async updateSyncRecord(
    id: string,
    data: {
      status: 'completed' | 'failed';
      records_synced?: number;
      records_created?: number;
      records_updated?: number;
      error_message?: string;
    },
  ): Promise<void> {
    const { error } = await this.supabase
      .from('sync_status')
      .update({
        status: data.status,
        completed_at: new Date().toISOString(),
        records_synced: data.records_synced,
        records_created: data.records_created,
        records_updated: data.records_updated,
        error_message: data.error_message,
      })
      .eq('id', id);

    if (error) {
      this.logger.error('Erreur mise à jour sync record', error);
    }
  }

  /**
   * Build address from Factorial employee data
   */
  private buildAddress(employee: any): string | undefined {
    const parts: string[] = [];
    if (employee.address_line_1) parts.push(employee.address_line_1);
    if (employee.postal_code && employee.city) {
      parts.push(`${employee.postal_code} ${employee.city}`);
    } else if (employee.city) {
      parts.push(employee.city);
    }
    if (employee.country) parts.push(employee.country);
    return parts.length > 0 ? parts.join(', ') : undefined;
  }

  /**
   * Find team name for an employee
   */
  private findTeamForEmployee(
    employeeId: number,
    teams: FactorialTeam[],
  ): { teamId: number; teamName: string } | null {
    for (const team of teams) {
      if (team.employee_ids?.includes(employeeId)) {
        return { teamId: team.id, teamName: team.name };
      }
    }
    return null;
  }

  /**
   * Get custom field value for an employee
   */
  private getCustomFieldValue(
    employeeId: number,
    fieldLabel: string,
    customFields: any[],
    customFieldValues: any[],
  ): string | undefined {
    const field = customFields.find(
      (f) => f.label && f.label.toLowerCase() === fieldLabel.toLowerCase(),
    );
    if (!field) return undefined;

    const value = customFieldValues.find(
      (v) => v.employee_id === employeeId && v.field_id === field.id,
    );
    return value?.value;
  }

  /**
   * Sync drivers from Factorial API to cache
   */
  async syncDrivers(triggeredBy?: string): Promise<SyncResultDto> {
    const startTime = Date.now();
    const syncId = await this.createSyncRecord('drivers', triggeredBy);

    try {
      this.logger.log('Démarrage synchronisation des conducteurs depuis Factorial...');

      // Fetch all data from Factorial
      const [employees, teams, customFields, customFieldValues] = await Promise.all([
        this.factorialService.getAllEmployees(),
        this.factorialService.getAllTeams(),
        this.factorialService.getCustomFields(),
        this.factorialService.getCustomFieldValues(),
      ]);

      this.logger.log(
        `Factorial: ${employees.length} employés, ${teams.length} équipes récupérés`,
      );

      let created = 0;
      let updated = 0;

      // Process each employee
      for (const employee of employees) {
        const teamInfo = this.findTeamForEmployee(employee.id, teams);
        const shift = this.getCustomFieldValue(
          employee.id,
          'shift',
          customFields,
          customFieldValues,
        );
        const availableWeekends = this.getCustomFieldValue(
          employee.id,
          'availableOnWeekends',
          customFields,
          customFieldValues,
        );

        const result = await this.driversCacheService.upsertFromApi({
          factorial_id: employee.id,
          first_name: employee.first_name,
          last_name: employee.last_name,
          email: employee.email,
          phone: employee.phone_number,
          address: this.buildAddress(employee),
          postal_code: employee.postal_code,
          city: employee.city,
          country: employee.country,
          birthday: employee.birthday_on,
          team_id: teamInfo?.teamId,
          team_name: teamInfo?.teamName,
          shift: shift,
          available_weekends: availableWeekends,
        });

        if (result.created) created++;
        if (result.updated) updated++;
      }

      const duration = Date.now() - startTime;

      await this.updateSyncRecord(syncId, {
        status: 'completed',
        records_synced: employees.length,
        records_created: created,
        records_updated: updated,
      });

      this.logger.log(
        `Synchronisation conducteurs terminée: ${created} créés, ${updated} mis à jour (${duration}ms)`,
      );

      return {
        entityType: 'drivers',
        status: 'completed',
        recordsSynced: employees.length,
        recordsCreated: created,
        recordsUpdated: updated,
        startedAt: new Date(startTime).toISOString(),
        completedAt: new Date().toISOString(),
        durationMs: duration,
      };
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : String(error);
      
      await this.updateSyncRecord(syncId, {
        status: 'failed',
        error_message: errorMessage,
      });

      this.logger.error('Erreur synchronisation conducteurs', error);
      throw new BadRequestException(`Erreur synchronisation: ${errorMessage}`);
    }
  }

  /**
   * Sync vehicles from MyRentCar API to cache
   */
  async syncVehicles(triggeredBy?: string): Promise<SyncResultDto> {
    const startTime = Date.now();
    const syncId = await this.createSyncRecord('vehicles', triggeredBy);

    try {
      this.logger.log('Démarrage synchronisation des véhicules depuis MyRentCar...');

      // Fetch all vehicles from MyRentCar
      const vehicles = await this.myRentACarService.getAllVehicleDetails();

      this.logger.log(`MyRentCar: ${vehicles.length} véhicules récupérés`);

      let created = 0;
      let updated = 0;

      // Process each vehicle
      for (const vehicle of vehicles) {
        const result = await this.vehiclesCacheService.upsertFromApi({
          myrentcar_id: vehicle.ID,
          numero: vehicle.Numero,
          immatriculation: vehicle.Immat1,
          type: vehicle.TypeVehicule?.Intitule,
          type_code: vehicle.TypeVehicule?.Code,
          marque_modele: vehicle.MarqueType,
          energie: vehicle.Carburant?.Intitule,
          energie_id: vehicle.Carburant?.ID,
          kilometrage: vehicle.DernierKm,
          date_dernier_km: vehicle.DateDernierKm,
          date_mise_circulation: vehicle.DateMiseCirculation,
          capacite_reservoir: vehicle.CapaciteReservoir,
          poids_vide: vehicle.PoidsVide,
          poids_charge: vehicle.PoidsCharge,
          prime_volume: vehicle.PrimeVolume,
          agence_proprietaire: vehicle.AgenceProprietaire,
          category_code: vehicle.Categorie?.Code,
        });

        if (result.created) created++;
        if (result.updated) updated++;
      }

      const duration = Date.now() - startTime;

      await this.updateSyncRecord(syncId, {
        status: 'completed',
        records_synced: vehicles.length,
        records_created: created,
        records_updated: updated,
      });

      this.logger.log(
        `Synchronisation véhicules terminée: ${created} créés, ${updated} mis à jour (${duration}ms)`,
      );

      return {
        entityType: 'vehicles',
        status: 'completed',
        recordsSynced: vehicles.length,
        recordsCreated: created,
        recordsUpdated: updated,
        startedAt: new Date(startTime).toISOString(),
        completedAt: new Date().toISOString(),
        durationMs: duration,
      };
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : String(error);
      
      await this.updateSyncRecord(syncId, {
        status: 'failed',
        error_message: errorMessage,
      });

      this.logger.error('Erreur synchronisation véhicules', error);
      throw new BadRequestException(`Erreur synchronisation: ${errorMessage}`);
    }
  }

  /**
   * Sync both drivers and vehicles
   */
  async syncAll(triggeredBy?: string): Promise<{
    drivers: SyncResultDto;
    vehicles: SyncResultDto;
  }> {
    const [driversResult, vehiclesResult] = await Promise.all([
      this.syncDrivers(triggeredBy),
      this.syncVehicles(triggeredBy),
    ]);

    return {
      drivers: driversResult,
      vehicles: vehiclesResult,
    };
  }

  /**
   * Get current sync status
   */
  async getStatus(): Promise<SyncStatusDto> {
    const status: SyncStatusDto = {};

    // Get last driver sync
    const { data: driverSync } = await this.supabase
      .from('sync_status')
      .select('*')
      .eq('entity_type', 'drivers')
      .eq('status', 'completed')
      .order('completed_at', { ascending: false })
      .limit(1)
      .single();

    if (driverSync) {
      const driverCount = await this.driversCacheService.getCount();
      status.drivers = {
        lastSyncAt: driverSync.completed_at,
        lastSyncStatus: driverSync.status,
        recordsCount: driverCount,
      };
    }

    // Get last vehicle sync
    const { data: vehicleSync } = await this.supabase
      .from('sync_status')
      .select('*')
      .eq('entity_type', 'vehicles')
      .eq('status', 'completed')
      .order('completed_at', { ascending: false })
      .limit(1)
      .single();

    if (vehicleSync) {
      const vehicleCount = await this.vehiclesCacheService.getCount();
      status.vehicles = {
        lastSyncAt: vehicleSync.completed_at,
        lastSyncStatus: vehicleSync.status,
        recordsCount: vehicleCount,
      };
    }

    // Check for in-progress sync
    const { data: inProgressSync } = await this.supabase
      .from('sync_status')
      .select('*')
      .eq('status', 'in_progress')
      .order('started_at', { ascending: false })
      .limit(1)
      .single();

    if (inProgressSync) {
      status.currentSync = {
        entityType: inProgressSync.entity_type,
        status: inProgressSync.status,
        startedAt: inProgressSync.started_at,
        recordsSynced: inProgressSync.records_synced || 0,
      };
    }

    return status;
  }

  /**
   * Get sync history
   */
  async getHistory(limit = 10): Promise<SyncHistoryEntryDto[]> {
    const { data, error } = await this.supabase
      .from('sync_status')
      .select('*')
      .order('started_at', { ascending: false })
      .limit(limit);

    if (error) {
      this.logger.error('Erreur récupération historique sync', error);
      throw new BadRequestException(error.message);
    }

    return (data || []).map((row: any) => ({
      id: row.id,
      entityType: row.entity_type,
      status: row.status,
      startedAt: row.started_at,
      completedAt: row.completed_at,
      recordsSynced: row.records_synced || 0,
      recordsCreated: row.records_created || 0,
      recordsUpdated: row.records_updated || 0,
      errorMessage: row.error_message,
      triggeredBy: row.triggered_by,
    }));
  }
}
