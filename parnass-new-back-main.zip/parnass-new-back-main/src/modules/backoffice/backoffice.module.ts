import { Module } from '@nestjs/common';
import { HttpModule } from '@nestjs/axios';

// Config
import { SupabaseService } from '../../config/supabase.service';

// Controllers
import { DriversController } from './controllers/drivers.controller';
import { VehiclesController } from './controllers/vehicles.controller';
import { SyncController } from './controllers/sync.controller';
import { RHController } from './controllers/rh.controller';

// Services
import { FactorialService } from './services/factorial.service';
import { MyRentACarService } from './services/my-rent-a-car.service';
import { DriversCacheService } from './services/drivers-cache.service';
import { VehiclesCacheService } from './services/vehicles-cache.service';
import { SyncService } from './services/sync.service';
import { RHService } from './services/rh.service';

@Module({
  imports: [
    HttpModule.register({
      timeout: 30000,
      maxRedirects: 5,
    }),
  ],
  controllers: [
    DriversController,
    VehiclesController,
    SyncController,
    RHController,
  ],
  providers: [
    SupabaseService,
    FactorialService,
    MyRentACarService,
    DriversCacheService,
    VehiclesCacheService,
    SyncService,
    RHService,
  ],
  exports: [
    FactorialService,
    MyRentACarService,
    DriversCacheService,
    VehiclesCacheService,
    SyncService,
    RHService,
  ],
})
export class BackofficeModule {}
