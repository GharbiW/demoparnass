import {
  IsString,
  IsOptional,
  IsNumber,
  IsArray,
  IsIn,
  IsDate,
  IsUUID,
} from 'class-validator';
import { Type } from 'class-transformer';

// ============================================
// Vehicle Cache DTOs
// ============================================

/**
 * Response DTO for a vehicle from the cache
 * Includes metadata about which fields come from API vs manual entry
 */
export class VehicleCacheResponseDto {
  @IsUUID()
  id: string;

  @IsNumber()
  myrentcarId: number;

  // Fields from MyRentCar API
  @IsString()
  @IsOptional()
  numero?: string;

  @IsString()
  immatriculation: string;

  @IsString()
  @IsOptional()
  type?: string;

  @IsString()
  @IsOptional()
  typeCode?: string;

  @IsString()
  @IsOptional()
  marqueModele?: string;

  @IsString()
  @IsOptional()
  energie?: string;

  @IsNumber()
  @IsOptional()
  energieId?: number;

  @IsNumber()
  @IsOptional()
  kilometrage?: number;

  @IsString()
  @IsOptional()
  dateDernierKm?: string;

  @IsString()
  @IsOptional()
  dateMiseCirculation?: string;

  @IsNumber()
  @IsOptional()
  capaciteReservoir?: number;

  @IsString()
  @IsOptional()
  poidsVide?: string;

  @IsString()
  @IsOptional()
  poidsCharge?: string;

  @IsNumber()
  @IsOptional()
  primeVolume?: number;

  @IsString()
  @IsOptional()
  agenceProprietaire?: string;

  @IsString()
  @IsOptional()
  categoryCode?: string;

  @IsString()
  @IsOptional()
  numeroSerie?: string;

  // Manual fields (not from API - shown underlined in UI)
  @IsString()
  @IsIn(['disponible', 'en_tournee', 'maintenance', 'indisponible'])
  status: string;

  @IsArray()
  @IsString({ each: true })
  semiCompatibles: string[];

  @IsArray()
  @IsString({ each: true })
  equipements: string[];

  @IsString()
  @IsOptional()
  localisation?: string;

  @IsString()
  @IsOptional()
  lastPositionUpdate?: string;

  @IsString()
  @IsOptional()
  prochainCt?: string;

  @IsString()
  @IsOptional()
  prochainEntretien?: string;

  @IsUUID()
  @IsOptional()
  titulaireId?: string;

  // Titulaire details (joined from driver_cache)
  @IsOptional()
  titulaire?: {
    id: string;
    nom: string;
  };

  // Maintenance details (only when status is 'maintenance')
  @IsOptional()
  maintenanceDetails?: {
    type: string;
    dateEntree: string;
    etr: string;
  };

  // Metadata for UI to know which fields are from API
  @IsArray()
  @IsString({ each: true })
  _apiFields: string[];

  @IsString()
  syncedAt: string;

  @IsString()
  createdAt: string;

  @IsString()
  updatedAt: string;
}

/**
 * DTO for updating manual vehicle fields (not from API)
 */
export class UpdateVehicleManualFieldsDto {
  @IsString()
  @IsIn(['disponible', 'en_tournee', 'maintenance', 'indisponible'])
  @IsOptional()
  status?: string;

  @IsArray()
  @IsString({ each: true })
  @IsOptional()
  semiCompatibles?: string[];

  @IsArray()
  @IsString({ each: true })
  @IsOptional()
  equipements?: string[];

  @IsString()
  @IsOptional()
  localisation?: string;

  @Type(() => Date)
  @IsDate()
  @IsOptional()
  lastPositionUpdate?: Date;

  @Type(() => Date)
  @IsDate()
  @IsOptional()
  prochainCt?: Date;

  @Type(() => Date)
  @IsDate()
  @IsOptional()
  prochainEntretien?: Date;

  @IsUUID()
  @IsOptional()
  titulaireId?: string;

  @IsString()
  @IsOptional()
  maintenanceType?: string;

  @Type(() => Date)
  @IsDate()
  @IsOptional()
  maintenanceDateEntree?: Date;

  @Type(() => Date)
  @IsDate()
  @IsOptional()
  maintenanceEtr?: Date;
}

/**
 * DTO for vehicle stats summary
 */
export class VehicleStatsDto {
  @IsNumber()
  total: number;

  @IsNumber()
  disponibles: number;

  @IsNumber()
  enTournee: number;

  @IsNumber()
  maintenance: number;

  @IsNumber()
  indisponibles: number;

  @IsString()
  @IsOptional()
  lastSyncAt?: string;
}

/**
 * Query params for listing vehicles
 */
export class ListVehiclesQueryDto {
  @IsString()
  @IsOptional()
  status?: string;

  @IsString()
  @IsOptional()
  search?: string;

  @IsString()
  @IsOptional()
  type?: string;

  @IsString()
  @IsOptional()
  energie?: string;

  @IsNumber()
  @IsOptional()
  @Type(() => Number)
  limit?: number;

  @IsNumber()
  @IsOptional()
  @Type(() => Number)
  offset?: number;
}

// List of fields that come from MyRentCar API
export const VEHICLE_API_FIELDS = [
  'myrentcarId',
  'numero',
  'immatriculation',
  'type',
  'typeCode',
  'marqueModele',
  'energie',
  'energieId',
  'kilometrage',
  'dateDernierKm',
  'dateMiseCirculation',
  'capaciteReservoir',
  'poidsVide',
  'poidsCharge',
  'primeVolume',
  'agenceProprietaire',
  'categoryCode',
  'numeroSerie',
];

// List of manual fields (not from API)
export const VEHICLE_MANUAL_FIELDS = [
  'status',
  'semiCompatibles',
  'equipements',
  'localisation',
  'lastPositionUpdate',
  'prochainCt',
  'prochainEntretien',
  'titulaireId',
  'titulaire',
  'maintenanceDetails',
];
