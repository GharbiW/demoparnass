import {
  IsString,
  IsOptional,
  IsNotEmpty,
  MaxLength,
  IsIn,
  IsBoolean,
  IsArray,
  IsUUID,
  IsNumber,
  Min,
  Matches,
  ArrayMinSize,
  ValidateNested,
} from 'class-validator';
import { Type } from 'class-transformer';

// DTO for each ride in the itinerary (1 étape = 1 complete ride with departure + arrival)
export class EtapeDto {
  // Departure address (required)
  @IsUUID('4')
  @IsNotEmpty({ message: "L'adresse de départ est requise" })
  addressDepart: string;

  // Arrival address (required for non-MAD, same as departure for MAD)
  @IsUUID('4')
  @IsOptional()
  addressArrivee?: string;

  // Legacy field - kept for backward compatibility
  @IsUUID('4')
  @IsOptional()
  addressId?: string;

  // 4 mandatory timestamps for ride definition (HH:mm format)
  @IsString()
  @IsOptional()
  @Matches(/^([01]?[0-9]|2[0-3]):[0-5][0-9]$/, {
    message: "L'heure de présence doit être au format HH:mm",
  })
  heurePresence?: string;

  @IsString()
  @IsOptional()
  @Matches(/^([01]?[0-9]|2[0-3]):[0-5][0-9]$/, {
    message: "L'heure de départ doit être au format HH:mm",
  })
  heureDepart?: string;

  @IsString()
  @IsOptional()
  @Matches(/^([01]?[0-9]|2[0-3]):[0-5][0-9]$/, {
    message: "L'heure d'arrivée doit être au format HH:mm",
  })
  heureArrivee?: string;

  @IsString()
  @IsOptional()
  @Matches(/^([01]?[0-9]|2[0-3]):[0-5][0-9]$/, {
    message: "L'heure de fin doit être au format HH:mm",
  })
  heureFin?: string;

  @IsBoolean()
  @IsOptional()
  vide?: boolean;

  // Comment for individual ride/step
  @IsString()
  @IsOptional()
  comment?: string;
}

export class CreatePrestationDto {
  @IsUUID()
  @IsNotEmpty()
  contractId: string;

  // Editable client reference - if empty, internal reference is used
  @IsString()
  @IsOptional()
  @MaxLength(100)
  referenceClient?: string;

  @IsArray()
  @IsString({ each: true })
  @IsOptional()
  frequence?: string[];

  @IsString()
  @IsOptional()
  @IsIn(['Régulière', 'SUP', 'MAD'])
  typeDemande?: string;

  @IsString()
  @IsOptional()
  @Matches(/^([01]?[0-9]|2[0-3]):[0-5][0-9]$/, {
    message: 'heureDepart must be in HH:mm format',
  })
  heureDepart?: string;

  @IsString()
  @IsOptional()
  @Matches(/^([01]?[0-9]|2[0-3]):[0-5][0-9]$/, {
    message: 'heureArrivee must be in HH:mm format',
  })
  heureArrivee?: string;

  // Array of ride objects: each étape = 1 complete ride
  // Each contains: addressDepart, addressArrivee, heurePresence, heureDepart, heureArrivee, heureFin
  // MAD type requires only 1 ride (returns to same point), others require at least 1
  @IsArray()
  @ValidateNested({ each: true })
  @Type(() => EtapeDto)
  @ArrayMinSize(1, {
    message: 'Au moins 1 étape est requise',
  })
  @IsNotEmpty({ message: 'Les étapes sont requises' })
  etapes: EtapeDto[];

  // MCom-0012: Material constraints are required
  @IsString()
  @IsNotEmpty({ message: 'La typologie véhicule est requise' })
  @IsIn(['VL', 'SPL', 'CM', 'Caisse Mobile'])
  typologieVehicule: string;

  @IsString()
  @IsNotEmpty({ message: "L'énergie imposée est requise" })
  @IsIn(['Gazole', 'Elec', 'Gaz'])
  energieImposee: string;

  @IsString()
  @IsNotEmpty({ message: 'Le type de remorque est requis' })
  @IsIn([
    'Frigo',
    'Hayon',
    'Aérienne',
    'Plateau',
    'Tautliner',
    'Benne',
    'Fourgon',
    'Savoyarde',
    'Citerne',
  ])
  typeRemorque: string;

  // MCom-0013: Equipment specificities (multi-select)
  @IsArray()
  @IsString({ each: true })
  @IsOptional()
  specificites?: string[];

  @IsBoolean()
  @IsOptional()
  sensible?: boolean;

  @IsString()
  @IsOptional()
  @MaxLength(50)
  codeDechargement?: string;

  @IsString()
  @IsOptional()
  comment?: string;

  // Billing flag (À facturer)
  @IsBoolean()
  @IsOptional()
  aFacturer?: boolean;

  // Planned mileage in km (mandatory for MAD type)
  @IsNumber()
  @IsOptional()
  @Min(0)
  kilometragePrevu?: number;

  // Actual mileage in km (from book P / Solide)
  @IsNumber()
  @IsOptional()
  @Min(0)
  kilometrageReel?: number;

  // MCom-0015: Price/Tariff with type
  @IsString()
  @IsOptional()
  @IsIn(['forfaitaire', 'terme_kilometrique', 'taux_horaire'])
  typeTarif?: string; // Forfaitaire, Terme Kilométrique (prix/km), Taux horaire

  @IsNumber()
  @IsOptional()
  @Min(0)
  tarif?: number;

  // Tariff unit (par trajet, par km, forfait, par heure, etc.)
  @IsString()
  @IsOptional()
  @MaxLength(50)
  tarifUnite?: string;

  // MCom-25: Contractual billing amounts
  // Contractual km for TK tariff type
  @IsNumber()
  @IsOptional()
  @Min(0)
  tarifKmContractuel?: number;

  // Contractual hours for hourly rate tariff type
  @IsNumber()
  @IsOptional()
  @Min(0)
  tarifHeuresContractuel?: number;
}
